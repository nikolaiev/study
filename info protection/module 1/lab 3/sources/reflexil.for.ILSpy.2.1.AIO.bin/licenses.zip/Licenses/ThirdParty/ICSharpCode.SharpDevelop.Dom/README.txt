#develop (short for SharpDevelop) is a free IDE for .NET programming languages.
Website: http://www.icsharpcode.net/OpenSource/SD/Default.aspx
Forums: http://community.sharpdevelop.net/forums/
Nightly builds: http://build.sharpdevelop.net/BuildArtefacts

Copyright 2012 AlphaSierraPapa for the SharpDevelop team
License: SharpDevelop is distributed under the LGPL.

The #develop project started on September 11th, 2000. The project was initiated
by Mike Kr�ger. In the course of the project, several contributors joined in.
If you want to contribute see http://wiki.sharpdevelop.net/JoiningTheTeam.ashx.

SharpDevelop Contributors:
	Mike Kr�ger (Project Founder)
	Daniel Grunwald (Technical Lead)
	Matt Ward
	David Srbecky (Debugger)
	Siegfried Pammer
	Peter Forstmeier (SharpDevelop Reports)
	
	(for a full list see http://wiki.sharpdevelop.net/Contributors.ashx)
﻿namespace CryptoLib
{
    public enum Alphabets
    {
        Ukrainian,English
    }

}
